# Личный Профиль - Веб-приложение

Современное веб-приложение для создания и управления личным профилем с интеграцией GitHub и генерацией PDF-резюме.

![Скриншот профиля](https://via.placeholder.com/800x400/667eea/ffffff?text=Personal+Profile)

## 🌟 Особенности

- **Современный дизайн** - Адаптивный интерфейс с плавными анимациями
- **Редактирование профиля** - Удобная форма для обновления информации
- **Валидация данных** - Проверка полей на клиенте и сервере
- **GitHub интеграция** - Автоматическое отображение репозиториев
- **PDF резюме** - Генерация профессионального резюме
- **Адаптивность** - Работает на всех устройствах
- **База данных** - SQLite для хранения данных

## 🚀 Быстрый старт

### Предварительные требования

- Node.js (версия 14 или выше)
- npm или yarn

### Установка

1. **Клонируйте репозиторий**
   ```bash
   git clone <repository-url>
   cd personal-profile
   ```

2. **Установите зависимости**
   ```bash
   npm install
   ```

3. **Инициализируйте базу данных**
   ```bash
   npm run init-db
   ```

4. **Запустите сервер**
   ```bash
   npm start
   ```

5. **Откройте приложение**
   Перейдите по адресу: http://localhost:3000

### Разработка

Для запуска в режиме разработки с автоперезагрузкой:

```bash
npm run dev
```

## 📁 Структура проекта

```
personal-profile/
├── public/                 # Статические файлы
│   ├── index.html         # Главная страница
│   ├── styles/
│   │   └── main.css       # Стили
│   └── js/
│       └── app.js         # JavaScript логика
├── scripts/
│   └── init-database.js   # Скрипт инициализации БД
├── server.js              # Основной сервер
├── package.json           # Зависимости проекта
└── README.md              # Документация
```

## 🗄️ База данных

Приложение использует SQLite для хранения данных профиля. База автоматически создается при инициализации с примерными данными.

### Структура таблиц:

- **profile** - Основная информация о пользователе
- **skills** - Навыки с уровнями владения
- **experience** - Опыт работы
- **education** - Образование
- **projects** - Проекты

## 🔧 API Endpoints

### Profile API

- `GET /api/profile` - Получить данные профиля
- `PUT /api/profile` - Обновить профиль

### GitHub API

- `GET /api/github/repos/:username` - Получить репозитории пользователя

### PDF API

- `GET /api/resume/pdf` - Скачать резюме в PDF

## 🎨 Кастомизация

### Изменение стилей

Основные переменные CSS находятся в `:root` секции файла `public/styles/main.css`:

```css
:root {
    --primary-color: #667eea;     /* Основной цвет */
    --secondary-color: #f7fafc;   /* Вторичный цвет */
    --accent-color: #ed64a6;      /* Акцентный цвет */
    --text-primary: #2d3748;      /* Основной текст */
    --text-secondary: #4a5568;    /* Вторичный текст */
}
```

### Добавление новых секций

1. Добавьте HTML-разметку в `public/index.html`
2. Добавьте стили в `public/styles/main.css`
3. Обновите JavaScript логику в `public/js/app.js`

## 📱 Адаптивность

Приложение полностью адаптивно и оптимизировано для:

- **Desktop** (1200px+)
- **Tablet** (768px - 1199px)
- **Mobile** (до 767px)

## 🔒 Безопасность

- Валидация входных данных на сервере
- Защита от SQL-инъекций через параметризованные запросы
- CORS настроен для разработки
- Санитизация пользовательского ввода

## 🧪 Тестирование

```bash
# Запуск с примерами данных
npm run init-db

# Проверка API
curl http://localhost:3000/api/profile

# Генерация PDF
curl -o resume.pdf http://localhost:3000/api/resume/pdf
```

## 🚀 Развертывание

### В продакшн

1. **Настройте переменные окружения**
   ```bash
   export NODE_ENV=production
   export PORT=3000
   ```

2. **Соберите приложение**
   ```bash
   npm start
   ```

3. **Настройте обратный прокси (nginx)**
   ```nginx
   server {
       listen 80;
       server_name yourdomain.com;
       
       location / {
           proxy_pass http://localhost:3000;
           proxy_http_version 1.1;
           proxy_set_header Upgrade $http_upgrade;
           proxy_set_header Connection 'upgrade';
           proxy_set_header Host $host;
           proxy_cache_bypass $http_upgrade;
       }
   }
   ```

### Docker (опционально)

Создайте `Dockerfile`:

```dockerfile
FROM node:18-alpine

WORKDIR /app

COPY package*.json ./
RUN npm ci --only=production

COPY . .

EXPOSE 3000

CMD ["npm", "start"]
```

Соберите и запустите:

```bash
docker build -t personal-profile .
docker run -p 3000:3000 personal-profile
```

## 🤝 Вклад в проект

1. Fork проекта
2. Создайте feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit изменения (`git commit -m 'Add some AmazingFeature'`)
4. Push в branch (`git push origin feature/AmazingFeature`)
5. Создайте Pull Request

## 📝 Лицензия

Этот проект распространяется под лицензией MIT. Смотрите файл `LICENSE` для деталей.

## 🆘 Поддержка

Если у вас есть вопросы или предложения:

- Создайте Issue в репозитории
- Напишите на email: support@example.com

## 🔄 История версий

### v1.0.0
- Базовая функциональность профиля
- GitHub интеграция
- Генерация PDF резюме
- Адаптивный дизайн

---

**Автор:** MiniMax Agent  
**Версия:** 1.0.0  
**Дата:** 2024